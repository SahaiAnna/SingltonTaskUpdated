﻿/******************* 
 * Experiment *
 *******************/


// store info about the experiment session:
let expName = 'experiment';  // from the Builder filename that created this script
let expInfo = {
    'participant': `${util.pad(Number.parseFloat(util.randint(0, 999999)).toFixed(0), 6)}`,
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// Run 'Before Experiment' code from code
import * as random from 'random';
import {choice} from 'numpy/random';
import * as pd from 'pandas';
distractors = pd.read_csv("distractors.csv");
images = distractors["image"];
fixation_size = [15, 15];
circle_size = [70, 70];
rectangle_size = [70, 70];
color = "green";
colors = ["red", "green", "blue"];
image_size = [200, 200];
possible_positions = [[0, 250], [0, (- 250)], [250, 0], [(- 250), 0]];
conditions = ["present_emotional", "present_neutral", "absent_emotional", "absent_neutral"];
weights = [1, 1, 1, 1];

// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: false,
  color: new util.Color([0,0,0]),
  units: 'height',
  waitBlanking: true,
  backgroundImage: '',
  backgroundFit: 'none',
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(load_variablesRoutineBegin());
flowScheduler.add(load_variablesRoutineEachFrame());
flowScheduler.add(load_variablesRoutineEnd());
flowScheduler.add(experiment_introductionRoutineBegin());
flowScheduler.add(experiment_introductionRoutineEachFrame());
flowScheduler.add(experiment_introductionRoutineEnd());
flowScheduler.add(action_introductionRoutineBegin());
flowScheduler.add(action_introductionRoutineEachFrame());
flowScheduler.add(action_introductionRoutineEnd());
const action_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(action_loopLoopBegin(action_loopLoopScheduler));
flowScheduler.add(action_loopLoopScheduler);
flowScheduler.add(action_loopLoopEnd);



flowScheduler.add(perception_introductionRoutineBegin());
flowScheduler.add(perception_introductionRoutineEachFrame());
flowScheduler.add(perception_introductionRoutineEnd());
const perception_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(perception_loopLoopBegin(perception_loopLoopScheduler));
flowScheduler.add(perception_loopLoopScheduler);
flowScheduler.add(perception_loopLoopEnd);



flowScheduler.add(thank_youRoutineBegin());
flowScheduler.add(thank_youRoutineEachFrame());
flowScheduler.add(thank_youRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    // resources:
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2023.2.3';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  

  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);
  psychoJS.experiment.field_separator = '\t';


  return Scheduler.Event.NEXT;
}


var load_variablesClock;
var distractor_color;
var target_color;
var correct_response;
var current_condition;
var screen_components;
var circle;
var target;
var distractor;
var neutral_red_square;
var perception_text;
var action_text;
var target_present;
var image;
var code;
var experiment_introductionClock;
var experiment_intro_text;
var welcome_response;
var action_introductionClock;
var action_intro_respone;
var action_fixation_routineClock;
var action_fixation;
var actionClock;
var action_response;
var perception_introductionClock;
var perception_intro_respone;
var perception_fixation_routineClock;
var perception_fixation;
var perceptionClock;
var perception_response;
var thank_youClock;
var thank_you_text;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "load_variables"
  load_variablesClock = new util.Clock();
  // Run 'Begin Experiment' code from code
  distractor_color = "";
  target_color = "";
  correct_response = "";
  current_condition = "";
  screen_components = [];
  circle = "";
  target = "";
  distractor = "";
  neutral_red_square = "";
  perception_text = "In this task, you have to press the right arrow key if the white square is present and the left arrow key of the white square is absent as fast as possible.";
  action_text = "You will be shown some circles and one white square surrounding an emotional picture. The white square is your target.  Your task is to click on the white square while ignoring the emotional picture. If the white square is not there on the screen then click on the centre of the screen.";
  target_present = false;
  image = "";
  code = "";
  
  // Initialize components for Routine "experiment_introduction"
  experiment_introductionClock = new util.Clock();
  experiment_intro_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'experiment_intro_text',
    text: "Welcome to the experiment!\n\npress 'spacebar' to continue.",
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  welcome_response = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "action_introduction"
  action_introductionClock = new util.Clock();
  action_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'action_text',
    text: ((action_text + "\n") + "press 'spacebar' to continue"),
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  action_intro_respone = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "action_fixation_routine"
  action_fixation_routineClock = new util.Clock();
  action_fixation = new visual.ShapeStim ({
    win: psychoJS.window, name: 'action_fixation', units : 'pix', 
    vertices: 'cross', size:fixation_size,
    ori: 0.0, pos: [0, 0],
    anchor: 'center',
    lineWidth: 1.0, 
    colorSpace: 'rgb',
    lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: 0, interpolate: true,
  });
  
  // Initialize components for Routine "action"
  actionClock = new util.Clock();
  action_response = new core.Mouse({
    win: psychoJS.window,
  });
  action_response.mouseClock = new util.Clock();
  // Initialize components for Routine "perception_introduction"
  perception_introductionClock = new util.Clock();
  perception_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'perception_text',
    text: ((perception_text + "\n") + "press 'spacebar' to continue"),
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  perception_intro_respone = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "perception_fixation_routine"
  perception_fixation_routineClock = new util.Clock();
  perception_fixation = new visual.ShapeStim ({
    win: psychoJS.window, name: 'perception_fixation', units : 'pix', 
    vertices: 'cross', size:fixation_size,
    ori: 0.0, pos: [0, 0],
    anchor: 'center',
    lineWidth: 1.0, 
    colorSpace: 'rgb',
    lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: 0, interpolate: true,
  });
  
  // Initialize components for Routine "perception"
  perceptionClock = new util.Clock();
  perception_response = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "thank_you"
  thank_youClock = new util.Clock();
  thank_you_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'thank_you_text',
    text: 'thank you for your participation. :))',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var load_variablesComponents;
function load_variablesRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'load_variables' ---
    t = 0;
    load_variablesClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('load_variables.started', globalClock.getTime());
    // keep track of which components have finished
    load_variablesComponents = [];
    
    load_variablesComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function load_variablesRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'load_variables' ---
    // get current time
    t = load_variablesClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    load_variablesComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function load_variablesRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'load_variables' ---
    load_variablesComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('load_variables.stopped', globalClock.getTime());
    // the Routine "load_variables" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _welcome_response_allKeys;
var experiment_introductionComponents;
function experiment_introductionRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'experiment_introduction' ---
    t = 0;
    experiment_introductionClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('experiment_introduction.started', globalClock.getTime());
    welcome_response.keys = undefined;
    welcome_response.rt = undefined;
    _welcome_response_allKeys = [];
    // keep track of which components have finished
    experiment_introductionComponents = [];
    experiment_introductionComponents.push(experiment_intro_text);
    experiment_introductionComponents.push(welcome_response);
    
    experiment_introductionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function experiment_introductionRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'experiment_introduction' ---
    // get current time
    t = experiment_introductionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *experiment_intro_text* updates
    if (t >= 0.0 && experiment_intro_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      experiment_intro_text.tStart = t;  // (not accounting for frame time here)
      experiment_intro_text.frameNStart = frameN;  // exact frame index
      
      experiment_intro_text.setAutoDraw(true);
    }
    
    
    // *welcome_response* updates
    if (t >= 0.0 && welcome_response.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      welcome_response.tStart = t;  // (not accounting for frame time here)
      welcome_response.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { welcome_response.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { welcome_response.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { welcome_response.clearEvents(); });
    }
    
    if (welcome_response.status === PsychoJS.Status.STARTED) {
      let theseKeys = welcome_response.getKeys({keyList: ['space'], waitRelease: false});
      _welcome_response_allKeys = _welcome_response_allKeys.concat(theseKeys);
      if (_welcome_response_allKeys.length > 0) {
        welcome_response.keys = _welcome_response_allKeys[0].name;  // just the first key pressed
        welcome_response.rt = _welcome_response_allKeys[0].rt;
        welcome_response.duration = _welcome_response_allKeys[0].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    experiment_introductionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function experiment_introductionRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'experiment_introduction' ---
    experiment_introductionComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('experiment_introduction.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(welcome_response.corr, level);
    }
    psychoJS.experiment.addData('welcome_response.keys', welcome_response.keys);
    if (typeof welcome_response.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('welcome_response.rt', welcome_response.rt);
        psychoJS.experiment.addData('welcome_response.duration', welcome_response.duration);
        routineTimer.reset();
        }
    
    welcome_response.stop();
    // the Routine "experiment_introduction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _action_intro_respone_allKeys;
var action_introductionComponents;
function action_introductionRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'action_introduction' ---
    t = 0;
    action_introductionClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('action_introduction.started', globalClock.getTime());
    action_intro_respone.keys = undefined;
    action_intro_respone.rt = undefined;
    _action_intro_respone_allKeys = [];
    // keep track of which components have finished
    action_introductionComponents = [];
    action_introductionComponents.push(action_text);
    action_introductionComponents.push(action_intro_respone);
    
    action_introductionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function action_introductionRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'action_introduction' ---
    // get current time
    t = action_introductionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *action_text* updates
    if (t >= 0.0 && action_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      action_text.tStart = t;  // (not accounting for frame time here)
      action_text.frameNStart = frameN;  // exact frame index
      
      action_text.setAutoDraw(true);
    }
    
    
    // *action_intro_respone* updates
    if (t >= 0.0 && action_intro_respone.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      action_intro_respone.tStart = t;  // (not accounting for frame time here)
      action_intro_respone.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { action_intro_respone.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { action_intro_respone.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { action_intro_respone.clearEvents(); });
    }
    
    if (action_intro_respone.status === PsychoJS.Status.STARTED) {
      let theseKeys = action_intro_respone.getKeys({keyList: ['space'], waitRelease: false});
      _action_intro_respone_allKeys = _action_intro_respone_allKeys.concat(theseKeys);
      if (_action_intro_respone_allKeys.length > 0) {
        action_intro_respone.keys = _action_intro_respone_allKeys[0].name;  // just the first key pressed
        action_intro_respone.rt = _action_intro_respone_allKeys[0].rt;
        action_intro_respone.duration = _action_intro_respone_allKeys[0].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    action_introductionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function action_introductionRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'action_introduction' ---
    action_introductionComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('action_introduction.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(action_intro_respone.corr, level);
    }
    psychoJS.experiment.addData('action_intro_respone.keys', action_intro_respone.keys);
    if (typeof action_intro_respone.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('action_intro_respone.rt', action_intro_respone.rt);
        psychoJS.experiment.addData('action_intro_respone.duration', action_intro_respone.duration);
        routineTimer.reset();
        }
    
    action_intro_respone.stop();
    // the Routine "action_introduction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var action_loop;
function action_loopLoopBegin(action_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    action_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 90, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'action_loop'
    });
    psychoJS.experiment.addLoop(action_loop); // add the loop to the experiment
    currentLoop = action_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    action_loop.forEach(function() {
      snapshot = action_loop.getSnapshot();
    
      action_loopLoopScheduler.add(importConditions(snapshot));
      action_loopLoopScheduler.add(action_fixation_routineRoutineBegin(snapshot));
      action_loopLoopScheduler.add(action_fixation_routineRoutineEachFrame());
      action_loopLoopScheduler.add(action_fixation_routineRoutineEnd(snapshot));
      action_loopLoopScheduler.add(actionRoutineBegin(snapshot));
      action_loopLoopScheduler.add(actionRoutineEachFrame());
      action_loopLoopScheduler.add(actionRoutineEnd(snapshot));
      action_loopLoopScheduler.add(action_loopLoopEndIteration(action_loopLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function action_loopLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(action_loop);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function action_loopLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var perception_loop;
function perception_loopLoopBegin(perception_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    perception_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 90, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'perception_loop'
    });
    psychoJS.experiment.addLoop(perception_loop); // add the loop to the experiment
    currentLoop = perception_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    perception_loop.forEach(function() {
      snapshot = perception_loop.getSnapshot();
    
      perception_loopLoopScheduler.add(importConditions(snapshot));
      perception_loopLoopScheduler.add(perception_fixation_routineRoutineBegin(snapshot));
      perception_loopLoopScheduler.add(perception_fixation_routineRoutineEachFrame());
      perception_loopLoopScheduler.add(perception_fixation_routineRoutineEnd(snapshot));
      perception_loopLoopScheduler.add(perceptionRoutineBegin(snapshot));
      perception_loopLoopScheduler.add(perceptionRoutineEachFrame());
      perception_loopLoopScheduler.add(perceptionRoutineEnd(snapshot));
      perception_loopLoopScheduler.add(perception_loopLoopEndIteration(perception_loopLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function perception_loopLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(perception_loop);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function perception_loopLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var action_fixation_routineComponents;
function action_fixation_routineRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'action_fixation_routine' ---
    t = 0;
    action_fixation_routineClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('action_fixation_routine.started', globalClock.getTime());
    // keep track of which components have finished
    action_fixation_routineComponents = [];
    action_fixation_routineComponents.push(action_fixation);
    
    action_fixation_routineComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function action_fixation_routineRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'action_fixation_routine' ---
    // get current time
    t = action_fixation_routineClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *action_fixation* updates
    if (t >= 0.0 && action_fixation.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      action_fixation.tStart = t;  // (not accounting for frame time here)
      action_fixation.frameNStart = frameN;  // exact frame index
      
      action_fixation.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 2.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (action_fixation.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      action_fixation.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    action_fixation_routineComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function action_fixation_routineRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'action_fixation_routine' ---
    action_fixation_routineComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('action_fixation_routine.stopped', globalClock.getTime());
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var gotValidClick;
var actionComponents;
function actionRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'action' ---
    t = 0;
    actionClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(8.000000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('action.started', globalClock.getTime());
    // Run 'Begin Routine' code from action_code
    Math.random.shuffle(possible_positions);
    [pos_action_circle1, pos_action_circle2, pos_action_circle3, pos_action_target] = possible_positions;
    image = choice(images);
    code = image.split("/")[0];
    Math.random.shuffle(conditions);
    current_condition = Math.random.choices(conditions, {"weights": weights})[0];
    if ((current_condition === "present_emotional")) {
        psychoJS.experiment.addData("Target", "present");
        psychoJS.experiment.addData("Phase", "action");
        psychoJS.experiment.addData("Valence", code);
        for (var i, _pj_c = 0, _pj_a = util.range(3), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
            i = _pj_a[_pj_c];
            circle = new visual.ShapeStim({"win": psychoJS.window, "name": `circle_${i}`, "units": "pix", "size": circle_size, "vertices": "circle", "ori": 0.0, "pos": possible_positions[i], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 3.0), "interpolate": true});
            screen_components.push(circle);
        }
        distractor = new visual.ImageStim({"win": psychoJS.window, "name": "distractor", "units": "pix", "image": image, "mask": null, "anchor": "center", "ori": 0.0, "pos": [0, 0], "size": image_size, "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 6.0)});
        screen_components.push(distractor);
        target = new visual.Rect({"win": psychoJS.window, "name": "target", "units": "pix", "width": rectangle_size[0], "height": rectangle_size[1], "ori": 0.0, "pos": possible_positions[3], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 4.0), "interpolate": true});
        screen_components.push(target);
    } else {
        if ((current_condition === "present_neutral")) {
            psychoJS.experiment.addData("Target", "present");
            psychoJS.experiment.addData("Phase", "action");
            psychoJS.experiment.addData("Valence", "neutral");
            for (var i, _pj_c = 0, _pj_a = util.range(3), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
                i = _pj_a[_pj_c];
                circle = new visual.ShapeStim({"win": psychoJS.window, "name": `circle_${i}`, "units": "pix", "size": circle_size, "vertices": "circle", "ori": 0.0, "pos": possible_positions[i], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 3.0), "interpolate": true});
                screen_components.push(circle);
            }
            target = new visual.Rect({"win": psychoJS.window, "name": "target", "units": "pix", "width": rectangle_size[0], "height": rectangle_size[1], "ori": 0.0, "pos": possible_positions[3], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 4.0), "interpolate": true});
            screen_components.push(target);
            neutral_red_square = new visual.Rect({"win": psychoJS.window, "name": "red_square", "units": "pix", "width": image_size[0], "height": image_size[1], "ori": 0.0, "pos": [0, 0], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "red", "fillColor": "red", "opacity": null, "depth": (- 8.0), "interpolate": true});
            screen_components.push(neutral_red_square);
        } else {
            if ((current_condition === "absent_emotional")) {
                psychoJS.experiment.addData("Target", "Absent");
                psychoJS.experiment.addData("Phase", "action");
                psychoJS.experiment.addData("Valence", code);
                for (var i, _pj_c = 0, _pj_a = util.range(4), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
                    i = _pj_a[_pj_c];
                    circle = new visual.ShapeStim({"win": psychoJS.window, "name": `circle_${i}`, "units": "pix", "size": circle_size, "vertices": "circle", "ori": 0.0, "pos": possible_positions[i], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 3.0), "interpolate": true});
                    screen_components.push(circle);
                }
                target = new visual.ImageStim({"win": psychoJS.window, "name": "target", "units": "pix", "image": image, "mask": null, "anchor": "center", "ori": 0.0, "pos": [0, 0], "size": image_size, "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 6.0)});
                screen_components.push(target);
            } else {
                if ((current_condition === "absent_neutral")) {
                    psychoJS.experiment.addData("Target", "absent");
                    psychoJS.experiment.addData("Phase", "action");
                    psychoJS.experiment.addData("Valence", "neutral");
                    for (var i, _pj_c = 0, _pj_a = util.range(4), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
                        i = _pj_a[_pj_c];
                        circle = new visual.ShapeStim({"win": psychoJS.window, "name": `circle_${i}`, "units": "pix", "size": circle_size, "vertices": "circle", "ori": 0.0, "pos": possible_positions[i], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 3.0), "interpolate": true});
                        screen_components.push(circle);
                    }
                    target = new visual.Rect({"win": psychoJS.window, "name": "target", "units": "pix", "width": image_size[0], "height": image_size[1], "ori": 0.0, "pos": [0, 0], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "red", "fillColor": "red", "opacity": null, "depth": (- 8.0), "interpolate": true});
                    screen_components.push(target);
                } else {
                    console.log("something went wrong, option is not available");
                }
            }
        }
    }
    for (var component, _pj_c = 0, _pj_a = screen_components, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        component = _pj_a[_pj_c];
        component.setAutoDraw(true);
    }
    
    // setup some python lists for storing info about the action_response
    // current position of the mouse:
    action_response.x = [];
    action_response.y = [];
    action_response.leftButton = [];
    action_response.midButton = [];
    action_response.rightButton = [];
    action_response.time = [];
    action_response.clicked_name = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    actionComponents = [];
    actionComponents.push(action_response);
    
    actionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var prevButtonState;
var _mouseButtons;
var _mouseXYs;
function actionRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'action' ---
    // get current time
    t = actionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // *action_response* updates
    if (t >= 0.0 && action_response.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      action_response.tStart = t;  // (not accounting for frame time here)
      action_response.frameNStart = frameN;  // exact frame index
      
      action_response.status = PsychoJS.Status.STARTED;
      action_response.mouseClock.reset();
      prevButtonState = action_response.getPressed();  // if button is down already this ISN'T a new click
      }
    frameRemains = 0.0 + 8.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (action_response.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      action_response.status = PsychoJS.Status.FINISHED;
        }
    if (action_response.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = action_response.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          for (const obj of [target]) {
            if (obj.contains(action_response)) {
              gotValidClick = true;
              action_response.clicked_name.push(obj.name)
            }
          }
          _mouseXYs = action_response.getPos();
          action_response.x.push(_mouseXYs[0]);
          action_response.y.push(_mouseXYs[1]);
          action_response.leftButton.push(_mouseButtons[0]);
          action_response.midButton.push(_mouseButtons[1]);
          action_response.rightButton.push(_mouseButtons[2]);
          action_response.time.push(action_response.mouseClock.getTime());
          if (gotValidClick === true) { // end routine on response
            continueRoutine = false;
          }
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    actionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function actionRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'action' ---
    actionComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('action.stopped', globalClock.getTime());
    // Run 'End Routine' code from action_code
    for (var component, _pj_c = 0, _pj_a = screen_components, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        component = _pj_a[_pj_c];
        component.setAutoDraw(false);
    }
    screen_components = [];
    
    // store data for psychoJS.experiment (ExperimentHandler)
    if (action_response.x) {  psychoJS.experiment.addData('action_response.x', action_response.x[0])};
    if (action_response.y) {  psychoJS.experiment.addData('action_response.y', action_response.y[0])};
    if (action_response.leftButton) {  psychoJS.experiment.addData('action_response.leftButton', action_response.leftButton[0])};
    if (action_response.midButton) {  psychoJS.experiment.addData('action_response.midButton', action_response.midButton[0])};
    if (action_response.rightButton) {  psychoJS.experiment.addData('action_response.rightButton', action_response.rightButton[0])};
    if (action_response.time) {  psychoJS.experiment.addData('action_response.time', action_response.time[0])};
    if (action_response.clicked_name) {  psychoJS.experiment.addData('action_response.clicked_name', action_response.clicked_name[0])};
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _perception_intro_respone_allKeys;
var perception_introductionComponents;
function perception_introductionRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'perception_introduction' ---
    t = 0;
    perception_introductionClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    psychoJS.experiment.addData('perception_introduction.started', globalClock.getTime());
    perception_intro_respone.keys = undefined;
    perception_intro_respone.rt = undefined;
    _perception_intro_respone_allKeys = [];
    // keep track of which components have finished
    perception_introductionComponents = [];
    perception_introductionComponents.push(perception_text);
    perception_introductionComponents.push(perception_intro_respone);
    
    perception_introductionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function perception_introductionRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'perception_introduction' ---
    // get current time
    t = perception_introductionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *perception_text* updates
    if (t >= 0.0 && perception_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      perception_text.tStart = t;  // (not accounting for frame time here)
      perception_text.frameNStart = frameN;  // exact frame index
      
      perception_text.setAutoDraw(true);
    }
    
    
    // *perception_intro_respone* updates
    if (t >= 0.0 && perception_intro_respone.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      perception_intro_respone.tStart = t;  // (not accounting for frame time here)
      perception_intro_respone.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { perception_intro_respone.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { perception_intro_respone.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { perception_intro_respone.clearEvents(); });
    }
    
    if (perception_intro_respone.status === PsychoJS.Status.STARTED) {
      let theseKeys = perception_intro_respone.getKeys({keyList: ['space'], waitRelease: false});
      _perception_intro_respone_allKeys = _perception_intro_respone_allKeys.concat(theseKeys);
      if (_perception_intro_respone_allKeys.length > 0) {
        perception_intro_respone.keys = _perception_intro_respone_allKeys[0].name;  // just the first key pressed
        perception_intro_respone.rt = _perception_intro_respone_allKeys[0].rt;
        perception_intro_respone.duration = _perception_intro_respone_allKeys[0].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    perception_introductionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function perception_introductionRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'perception_introduction' ---
    perception_introductionComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('perception_introduction.stopped', globalClock.getTime());
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(perception_intro_respone.corr, level);
    }
    psychoJS.experiment.addData('perception_intro_respone.keys', perception_intro_respone.keys);
    if (typeof perception_intro_respone.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('perception_intro_respone.rt', perception_intro_respone.rt);
        psychoJS.experiment.addData('perception_intro_respone.duration', perception_intro_respone.duration);
        routineTimer.reset();
        }
    
    perception_intro_respone.stop();
    // the Routine "perception_introduction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var perception_fixation_routineComponents;
function perception_fixation_routineRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'perception_fixation_routine' ---
    t = 0;
    perception_fixation_routineClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('perception_fixation_routine.started', globalClock.getTime());
    // keep track of which components have finished
    perception_fixation_routineComponents = [];
    perception_fixation_routineComponents.push(perception_fixation);
    
    perception_fixation_routineComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function perception_fixation_routineRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'perception_fixation_routine' ---
    // get current time
    t = perception_fixation_routineClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *perception_fixation* updates
    if (t >= 0.0 && perception_fixation.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      perception_fixation.tStart = t;  // (not accounting for frame time here)
      perception_fixation.frameNStart = frameN;  // exact frame index
      
      perception_fixation.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 2.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (perception_fixation.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      perception_fixation.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    perception_fixation_routineComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function perception_fixation_routineRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'perception_fixation_routine' ---
    perception_fixation_routineComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('perception_fixation_routine.stopped', globalClock.getTime());
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _perception_response_allKeys;
var perceptionComponents;
function perceptionRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'perception' ---
    t = 0;
    perceptionClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(8.000000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('perception.started', globalClock.getTime());
    // Run 'Begin Routine' code from perception_code
    Math.random.shuffle(possible_positions);
    [pos_action_circle1, pos_action_circle2, pos_action_circle3, pos_action_target] = possible_positions;
    Math.random.shuffle(conditions);
    current_condition = Math.random.choices(conditions, {"weights": weights})[0];
    image = choice(images);
    code = image.split("/")[0];
    if ((current_condition === "present_emotional")) {
        target_present = true;
        psychoJS.experiment.addData("Target", "present");
        psychoJS.experiment.addData("Phase", "perception");
        psychoJS.experiment.addData("Valence", code);
        for (var i, _pj_c = 0, _pj_a = util.range(3), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
            i = _pj_a[_pj_c];
            circle = new visual.ShapeStim({"win": psychoJS.window, "name": `circle_${i}`, "units": "pix", "size": circle_size, "vertices": "circle", "ori": 0.0, "pos": possible_positions[i], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 3.0), "interpolate": true});
            screen_components.push(circle);
        }
        distractor = new visual.ImageStim({"win": psychoJS.window, "name": "distractor", "units": "pix", "image": image, "mask": null, "anchor": "center", "ori": 0.0, "pos": [0, 0], "size": image_size, "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 6.0)});
        screen_components.push(distractor);
        target = new visual.Rect({"win": psychoJS.window, "name": "target", "units": "pix", "width": rectangle_size[0], "height": rectangle_size[1], "ori": 0.0, "pos": possible_positions[3], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 4.0), "interpolate": true});
        screen_components.push(target);
    } else {
        if ((current_condition === "present_neutral")) {
            target_present = true;
            psychoJS.experiment.addData("Target", "present");
            psychoJS.experiment.addData("Phase", "perception");
            psychoJS.experiment.addData("Valence", "neutral");
            for (var i, _pj_c = 0, _pj_a = util.range(3), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
                i = _pj_a[_pj_c];
                circle = new visual.ShapeStim({"win": psychoJS.window, "name": `circle_${i}`, "units": "pix", "size": circle_size, "vertices": "circle", "ori": 0.0, "pos": possible_positions[i], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 3.0), "interpolate": true});
                screen_components.push(circle);
            }
            target = new visual.Rect({"win": psychoJS.window, "name": "target", "units": "pix", "width": rectangle_size[0], "height": rectangle_size[1], "ori": 0.0, "pos": possible_positions[3], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 4.0), "interpolate": true});
            screen_components.push(target);
            neutral_red_square = new visual.Rect({"win": psychoJS.window, "name": "red_square", "units": "pix", "width": image_size[0], "height": image_size[1], "ori": 0.0, "pos": [0, 0], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "red", "fillColor": "red", "opacity": null, "depth": (- 8.0), "interpolate": true});
            screen_components.push(neutral_red_square);
        } else {
            if ((current_condition === "absent_emotional")) {
                target_present = false;
                psychoJS.experiment.addData("Target", "Absent");
                psychoJS.experiment.addData("Phase", "perception");
                psychoJS.experiment.addData("Valence", code);
                for (var i, _pj_c = 0, _pj_a = util.range(4), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
                    i = _pj_a[_pj_c];
                    circle = new visual.ShapeStim({"win": psychoJS.window, "name": `circle_${i}`, "units": "pix", "size": circle_size, "vertices": "circle", "ori": 0.0, "pos": possible_positions[i], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 3.0), "interpolate": true});
                    screen_components.push(circle);
                }
                target = new visual.ImageStim({"win": psychoJS.window, "name": "target", "units": "pix", "image": image, "mask": null, "anchor": "center", "ori": 0.0, "pos": [0, 0], "size": image_size, "color": [1, 1, 1], "colorSpace": "rgb", "opacity": null, "flipHoriz": false, "flipVert": false, "texRes": 128.0, "interpolate": true, "depth": (- 6.0)});
                screen_components.push(target);
            } else {
                if ((current_condition === "absent_neutral")) {
                    target_present = false;
                    psychoJS.experiment.addData("Target", "absent");
                    psychoJS.experiment.addData("Phase", "perception");
                    psychoJS.experiment.addData("Valence", "neutral");
                    for (var i, _pj_c = 0, _pj_a = util.range(4), _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
                        i = _pj_a[_pj_c];
                        circle = new visual.ShapeStim({"win": psychoJS.window, "name": `circle_${i}`, "units": "pix", "size": circle_size, "vertices": "circle", "ori": 0.0, "pos": possible_positions[i], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "white", "fillColor": "white", "opacity": null, "depth": (- 3.0), "interpolate": true});
                        screen_components.push(circle);
                    }
                    target = new visual.Rect({"win": psychoJS.window, "name": "target", "units": "pix", "width": image_size[0], "height": image_size[1], "ori": 0.0, "pos": [0, 0], "anchor": "center", "lineWidth": 1.0, "colorSpace": "rgb", "lineColor": "red", "fillColor": "red", "opacity": null, "depth": (- 8.0), "interpolate": true});
                    screen_components.push(target);
                } else {
                    console.log("something went wrong, option is not available");
                }
            }
        }
    }
    for (var component, _pj_c = 0, _pj_a = screen_components, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        component = _pj_a[_pj_c];
        component.setAutoDraw(true);
    }
    
    perception_response.keys = undefined;
    perception_response.rt = undefined;
    _perception_response_allKeys = [];
    // keep track of which components have finished
    perceptionComponents = [];
    perceptionComponents.push(perception_response);
    
    perceptionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function perceptionRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'perception' ---
    // get current time
    t = perceptionClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *perception_response* updates
    if (t >= 0.0 && perception_response.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      perception_response.tStart = t;  // (not accounting for frame time here)
      perception_response.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { perception_response.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { perception_response.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { perception_response.clearEvents(); });
    }
    
    frameRemains = 0.0 + 8.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (perception_response.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      perception_response.status = PsychoJS.Status.FINISHED;
        }
      
    if (perception_response.status === PsychoJS.Status.STARTED) {
      let theseKeys = perception_response.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _perception_response_allKeys = _perception_response_allKeys.concat(theseKeys);
      if (_perception_response_allKeys.length > 0) {
        perception_response.keys = _perception_response_allKeys[_perception_response_allKeys.length - 1].name;  // just the last key pressed
        perception_response.rt = _perception_response_allKeys[_perception_response_allKeys.length - 1].rt;
        perception_response.duration = _perception_response_allKeys[_perception_response_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    perceptionComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function perceptionRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'perception' ---
    perceptionComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('perception.stopped', globalClock.getTime());
    // Run 'End Routine' code from perception_code
    for (var component, _pj_c = 0, _pj_a = screen_components, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        component = _pj_a[_pj_c];
        component.setAutoDraw(false);
    }
    psychoJS.experiment.addData("target_present", target_present);
    if ((target_present === true)) {
        if ((perception_response.keys === "right")) {
            correct_response = 1;
            psychoJS.experiment.addData("correct_response", 1);
        } else {
            if ((perception_response.keys === "left")) {
                correct_response = 0;
                psychoJS.experiment.addData("correct_response", 0);
            } else {
                console.log("response key is something else than left or right");
                psychoJS.experiment.addData("correct_response", "error");
            }
        }
    } else {
        if ((target_present === false)) {
            if ((perception_response.keys === "right")) {
                correct_response = 0;
                psychoJS.experiment.addData("correct_response", 0);
            } else {
                if ((perception_response.keys === "left")) {
                    correct_response = 1;
                    psychoJS.experiment.addData("correct_response", 1);
                } else {
                    console.log("response key is something else than left or right");
                    psychoJS.experiment.addData("correct_response", "error");
                }
            }
        } else {
            console.log("target is not present or absent");
            psychoJS.experiment.addData("correct_response", "target error");
        }
    }
    screen_components = [];
    
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(perception_response.corr, level);
    }
    psychoJS.experiment.addData('perception_response.keys', perception_response.keys);
    if (typeof perception_response.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('perception_response.rt', perception_response.rt);
        psychoJS.experiment.addData('perception_response.duration', perception_response.duration);
        routineTimer.reset();
        }
    
    perception_response.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var thank_youComponents;
function thank_youRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'thank_you' ---
    t = 0;
    thank_youClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(5.000000);
    // update component parameters for each repeat
    psychoJS.experiment.addData('thank_you.started', globalClock.getTime());
    // keep track of which components have finished
    thank_youComponents = [];
    thank_youComponents.push(thank_you_text);
    
    thank_youComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function thank_youRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'thank_you' ---
    // get current time
    t = thank_youClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *thank_you_text* updates
    if (t >= 0.0 && thank_you_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      thank_you_text.tStart = t;  // (not accounting for frame time here)
      thank_you_text.frameNStart = frameN;  // exact frame index
      
      thank_you_text.setAutoDraw(true);
    }
    
    frameRemains = 0.0 + 5.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (thank_you_text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      thank_you_text.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    thank_youComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function thank_youRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'thank_you' ---
    thank_youComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('thank_you.stopped', globalClock.getTime());
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  
  
  
  
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
